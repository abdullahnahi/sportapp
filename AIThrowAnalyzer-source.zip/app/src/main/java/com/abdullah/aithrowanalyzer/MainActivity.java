package com.abdullah.aithrowanalyzer;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.*;

import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 10, CAPTURE_VIDEO = 11, CAMERA_PERMISSION = 12;
    private final String[] sportKeys = {"javelin", "shot_put", "discus"};
    private final double[][] defaults = {{.8,.03,2.60,1.80,.25},{7,.12,.12,1.40,.47},{2,.22,.22,1.60,.60}};
    private Spinner sport;
    private EditText mass, diameter, length, height, drag, knownDistance, knownPixels, mpp, actual;
    private TextView selected, status, result;
    private Uri videoUri;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,32,28,40); root.setBackgroundColor(Color.rgb(7,17,31));
        scroll.addView(root); setContentView(scroll);

        TextView title = text("AI Sports Throw Analyzer", 26, Color.WHITE); root.addView(title);
        root.addView(text("Javelin • Shot Put • Discus", 15, Color.rgb(159,179,202)));
        section(root, "1. Sport and physical variables");
        sport = new Spinner(this); sport.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"Javelin / Arrow","Shot Put","Discus"})); root.addView(sport);
        mass = field(root,"Mass (kg)"); diameter=field(root,"Diameter (m)"); length=field(root,"Length (m)"); height=field(root,"Release height (m)"); drag=field(root,"Drag coefficient");
        sport.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){ public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p, View v,int pos,long id){applyDefaults(pos);} });

        section(root, "2. Camera calibration");
        knownDistance=field(root,"Known real distance (m)"); knownPixels=field(root,"That distance in pixels"); mpp=field(root,"Direct meter per pixel (optional)"); actual=field(root,"Actual measured throw distance (optional)");
        root.addView(text("Use a known distance in the same throwing plane for reliable metric results.",14,Color.rgb(243,191,87)));

        section(root, "3. Select or record a video");
        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button choose=button("Choose video"), camera=button("Record video"); buttons.addView(choose,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(camera,new LinearLayout.LayoutParams(0,-2,1)); root.addView(buttons);
        selected=text("No video selected",14,Color.LTGRAY); root.addView(selected);
        Button analyze=button("Analyze throw"); root.addView(analyze);
        status=text("Ready",15,Color.rgb(159,179,202)); root.addView(status);
        section(root,"4. Result"); result=text("—",16,Color.WHITE); result.setTextIsSelectable(true); root.addView(result);

        choose.setOnClickListener(v -> startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE), PICK_VIDEO));
        camera.setOnClickListener(v -> recordVideo());
        analyze.setOnClickListener(v -> analyze());
    }

    private void recordVideo(){
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION); return;}
        Intent i=new Intent(MediaStore.ACTION_VIDEO_CAPTURE); i.putExtra(MediaStore.EXTRA_DURATION_LIMIT,12); startActivityForResult(i,CAPTURE_VIDEO);
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g); if(r==CAMERA_PERMISSION&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)recordVideo();}
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data); if(c==RESULT_OK&&(r==PICK_VIDEO||r==CAPTURE_VIDEO)&&data!=null){videoUri=data.getData(); selected.setText("Video ready: "+videoUri.getLastPathSegment());}}

    private void analyze(){
        if(videoUri==null){Toast.makeText(this,"Choose or record a video first",Toast.LENGTH_SHORT).show(); return;}
        status.setText("Uploading and analyzing…"); result.setText("—");
        new Thread(() -> { try { JSONObject response=upload(videoUri, settings()); runOnUiThread(() -> showResponse(response)); } catch(Exception e){runOnUiThread(() -> status.setText("Error: "+e.getMessage()));} }).start();
    }
    private JSONObject settings() throws Exception {
        JSONObject x=new JSONObject(); x.put("sport",sportKeys[sport.getSelectedItemPosition()]); x.put("mass_kg",number(mass)); x.put("diameter_m",number(diameter)); x.put("length_m",number(length)); x.put("release_height_m",number(height)); x.put("drag_coefficient",number(drag)); x.put("known_distance_m",number(knownDistance)); x.put("known_distance_pixels",number(knownPixels)); x.put("meter_per_pixel",number(mpp)); x.put("actual_distance_m",number(actual)); return x;
    }
    private JSONObject upload(Uri uri,JSONObject settings) throws Exception {
        String boundary="----AIThrow"+System.currentTimeMillis(); URL url=new URL(BuildConfig.API_BASE_URL+"/api/analyze-video");
        HttpURLConnection c=(HttpURLConnection)url.openConnection(); c.setConnectTimeout(30000); c.setReadTimeout(300000); c.setDoOutput(true); c.setRequestMethod("POST"); c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
        try(OutputStream out=c.getOutputStream()){
            part(out,boundary,"settings",settings.toString());
            write(out,"--"+boundary+"\r\nContent-Disposition: form-data; name=\"video\"; filename=\"throw.mp4\"\r\nContent-Type: video/mp4\r\n\r\n");
            try(InputStream in=getContentResolver().openInputStream(uri)){byte[] b=new byte[65536]; int n; while((n=in.read(b))>0)out.write(b,0,n);} write(out,"\r\n--"+boundary+"--\r\n");
        }
        InputStream in=(c.getResponseCode()<400)?c.getInputStream():c.getErrorStream(); String body=read(in); JSONObject json=new JSONObject(body); if(c.getResponseCode()>=400)throw new IOException(json.optString("error","Server error")); return json;
    }
    private void showResponse(JSONObject r){ status.setText("Finished"); StringBuilder s=new StringBuilder(); line(s,"Sport",r.optString("sport_detected_label")); line(s,"Release time",fmt(r,"release_time_sec"," s")); line(s,"Release speed",fmt(r,"release_speed_m_s"," m/s")); line(s,"Release angle",fmt(r,"release_angle_deg","°")); line(s,"Predicted distance",fmt(r,"predicted_distance_m"," m")); line(s,"Confidence",fmt(r,"confidence_percent","%")); line(s,"Actual distance",fmt(r,"actual_distance_m"," m")); line(s,"Absolute error",fmt(r,"absolute_error_m"," m")); line(s,"Accuracy",fmt(r,"accuracy_percent","%")); result.setText(s.toString()); }

    private void applyDefaults(int p){EditText[] e={mass,diameter,length,height,drag}; for(int i=0;i<e.length;i++)e[i].setText(String.valueOf(defaults[p][i]));}
    private EditText field(LinearLayout root,String hint){EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(Color.GRAY); e.setTextColor(Color.WHITE); e.setInputType(8194); root.addView(e,new LinearLayout.LayoutParams(-1,-2)); return e;}
    private Button button(String name){Button b=new Button(this); b.setText(name); return b;}
    private TextView text(String value,int size,int color){TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setPadding(5,8,5,8); return t;}
    private void section(LinearLayout root,String name){TextView t=text(name,20,Color.WHITE); t.setPadding(0,28,0,8); root.addView(t);}
    private double number(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception x){return 0;}}
    private static void write(OutputStream o,String s)throws IOException{o.write(s.getBytes(StandardCharsets.UTF_8));}
    private static void part(OutputStream o,String b,String n,String v)throws IOException{write(o,"--"+b+"\r\nContent-Disposition: form-data; name=\""+n+"\"\r\n\r\n"+v+"\r\n");}
    private static String read(InputStream in)throws IOException{ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);return o.toString("UTF-8");}
    private static void line(StringBuilder s,String k,String v){s.append(k).append(": ").append(v).append("\n\n");}
    private static String fmt(JSONObject r,String k,String suffix){if(r.isNull(k)||!r.has(k))return "—";return String.format(java.util.Locale.US,"%.2f%s",r.optDouble(k),suffix);}
}
