# AI Sports Throw Analyzer

This package contains a native Android app and a Flask/OpenCV analysis backend.

## Security

Never put an OpenAI API key in the Android app. The key belongs only on the server as the `OPENAI_API_KEY` environment variable. The key found in the supplied prototype was intentionally removed and should be revoked.

## Build the Android APK

1. Open this folder in Android Studio (JDK 17).
2. In `app/build.gradle`, change `API_BASE_URL` to the HTTPS address of the deployed backend. `http://10.0.2.2:5000` works only with an Android emulator and a server running on the same computer.
3. Select **Build > Build APK(s)**.
4. For publishing, select **Build > Generate Signed Bundle / APK** and create a private signing key.

## Run the backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY='your-new-key'
export OPENAI_MODEL='gpt-5.6'
python sports_analyzer_backend.py
```

For a real phone, deploy the backend behind HTTPS and change `API_BASE_URL`. Uploaded videos and validation history are stored on the backend, not in the APK.
